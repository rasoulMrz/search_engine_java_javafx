/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import UI.SearchUI;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;

/**
 *
 * @author rasul
 */

public class SearchThread extends Thread{
    SearchUI ui;
    File dir;
    String  fName;
    
    boolean end = false;
    static final Map<String, ArrayList<File>> memory = new HashMap<>();
    ArrayList<File> foundFiles;
    boolean refresh;

    public void setEnd(boolean end) {
        this.end = end;
    }
     
    
    
    public SearchThread(File dir, String fName,  boolean  refresh) {
        this.setDaemon(true);
        this.ui = SearchUI.getInstance();
        this.refresh = refresh;
        this.dir = dir;
        
        this.fName = fName;
    }

    private void searchUnder(File dir) throws InterruptedException
    {
        if(end)
        {
            return;
        }
        File[] subDirs = dir.listFiles();
        
        
        if(subDirs != null)
        {////////we have two for statements to first report all wanted files and then go to other directories
            for(File f : subDirs)
            {
                if(end)
                {
                    return;
                }
                if(f.getName().contains(fName))
                {  
                    foundFiles.add(f);
                    Runnable runnable = new AddFile(f);
                    Platform.runLater(runnable);
                }
            }
            for(File f : subDirs)
            {
                if(end)
                {
                    return;
                }
                if(!end && f.isDirectory())
                    searchUnder(f);
            }
        }
    }
    
    
    @Override
    public void run() {
        try {
            end = false;
            if(memory.containsKey(fName + dir.getPath()) && !refresh)
            {
                //System.out.println(dir.getName());
                if(loadFromMem())
                {
                    Runnable endmsg = new EndMessage(2);
                    Platform.runLater(endmsg);
                }
                else
                {
                    Runnable endmsg = new EndMessage(1);
                    Platform.runLater(endmsg);
                }
            }
            else
            {
                foundFiles = new ArrayList<>();
                searchUnder(dir);
                if(end)
                {
                    foundFiles.add(null);
                }
                
                memory.put(fName+dir.getPath(), foundFiles);
                Runnable endmsg = new EndMessage(1);
                Platform.runLater(endmsg);
            }
            
            // TODO code application logic here
        } catch (InterruptedException ex) {
            System.out.println("message sending interrupted");
        }
    }

    boolean loadFromMem() throws InterruptedException
    {
 
        for(File f : memory.get(fName+dir.getPath()))
        {
            if( end)
            {
                return false;
            }
            if(f != null)
            {
                Runnable runnable = new AddFile(f);
                Platform.runLater(runnable);
            }
            else 
                return true;
        }

        return false;
    }
    
}

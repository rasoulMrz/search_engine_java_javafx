/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import UI.SearchUI;

/**
 *
 * @author rasul
 */
public class EndMessage implements Runnable{
    int mess;

    public EndMessage(int mess) {
        this.mess = mess;
    }
    
    @Override
    public void run() {
        SearchUI.getInstance().onSearchEnd(mess);
    }
    
}

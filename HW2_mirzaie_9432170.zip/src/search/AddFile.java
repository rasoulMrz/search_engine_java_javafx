/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import UI.SearchUI;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rasul
 */
public class AddFile implements Runnable{

    File f;

    public AddFile(File f) {
        this.f = f;
    }
    
    @Override
    public void run() {
        SearchUI.getInstance().addFile(f);
        
    }
    
}

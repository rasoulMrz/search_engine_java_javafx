/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

/**
 *
 * @author rasul
 */
public class SearchAction implements EventHandler<ActionEvent> {
    SearchUI ui;
    
    
    public SearchAction() {
        this.ui = SearchUI.getInstance();
    }



    @Override
    public void handle(ActionEvent t) {
        
        ui.search(false);
    }
    
}

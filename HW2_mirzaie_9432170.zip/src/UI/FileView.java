/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import java.io.File;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * @author rasul
 */
public class FileView  extends VBox{
    FileView(File f)
    {
        
        Label fname = new Label("File name :\t");
        TextField tf = new  TextField(f.getName());
        tf.setEditable(false);
        tf.setMinWidth(500);
        HBox hb = new HBox(fname, tf);
        Label path = new Label("Path :\t\t");
        tf = new TextField(f.getPath());
        tf.setEditable(false);
        tf.setMinWidth(500);
        HBox hb2 = new HBox(path, tf);
        hb.setPadding(new Insets(20));
        hb2.setPadding(new Insets(20));
        this.setStyle("-fx-padding: 5;" + 
              "-fx-border-style: solid inside;" + 
              "-fx-border-width: 2;" +
              "-fx-border-insets: 5;" + 
              "-fx-border-radius: 5;" + 
              "-fx-border-color: black;");
      
        this.getChildren().add(hb);
        this.getChildren().add(hb2);
        
        this.setMinWidth(710);
    }
}

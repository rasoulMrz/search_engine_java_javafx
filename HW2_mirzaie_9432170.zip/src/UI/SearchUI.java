/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;



import java.awt.Toolkit;
import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import static jdk.nashorn.internal.objects.NativeArray.map;

import search.SearchThread;
import sun.audio.AudioPlayer;

/**
 *
 * @author rasul
 */
public class SearchUI extends Application{
    
    TextField text = new TextField();
    ComboBox<File> dirCombo ;
    SearchThread searchThread = null;
    Stage popUpStage = null;
    VBox centerV = new VBox();
    Button searchButton;
    static SearchUI instance;

    public static SearchUI getInstance() {
        return instance;
    }
    
    boolean end = false;

    public SearchUI() {
        instance = this;
    }
    
    
    
            
    public void addFile(File f)
    {
        centerV.getChildren().add(new FileView(f));
    }

    public void search(boolean refresh) {

        if(dirCombo.getValue() != null ){
            end = false;
            searchButton.setDisable(true);
            centerV.getChildren().clear();

            
            searchThread = new SearchThread(dirCombo.getValue(), text.getText(), refresh);
            searchThread.start(); 
        }
    }
    @Override
    public void start(Stage stage){
        BorderPane border = new BorderPane();

        ObservableList<File> ob = FXCollections.observableArrayList(File.listRoots());
        dirCombo = new ComboBox<File>(ob);
        
        text.setMinWidth(550);
        searchButton = new Button("search in:");
        
        searchButton.setOnAction(new SearchAction());
        Button stopButton = new Button("Stop");
        stopButton.setOnAction(new StopAction());
       
        HBox topH = new HBox(text, stopButton, searchButton, dirCombo);
        topH.setMinSize(600, 2);
        border.setTop(topH);
        
         
        //set center
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToHeight(true);
        scrollPane.setContent(centerV);

        border.setCenter(scrollPane);
        
        Scene scene = new Scene(border);
        stage.setScene(scene);
        stage.setMinHeight(600);
        stage.setResizable(false);
        stage.show();        
    }
    public static void main(String[] args) {
        launch(args);
    }
    void popWindow()
    {
        if(popUpStage == null)
        {
            popUpStage = new Stage();
            Pane p = new Pane();
            Button noB = new Button("No");
            noB.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent t) {
                    popUpStage.close();
                }
            });
            Button okB = new Button("Yes");

            okB.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent t) {
                    popUpStage.close();
                    search(true);
                }
            });
            Label text = new Label("this is saved resualt of a stopped search\ndo you want to search again?");
            HBox hB = new HBox(noB, okB);
            VBox vB = new VBox(text, hB);
            p.getChildren().add(vB);
            popUpStage.setScene(new Scene(p));
            popUpStage.setMinWidth(200);
            popUpStage.setMinHeight(100);
        }
        if(!popUpStage.isShowing())     
            popUpStage.show();
       
        Toolkit.getDefaultToolkit().beep();
        popUpStage.setAlwaysOnTop(true);
    }

    public void onSearchEnd(int m) {
        if(m == 2)
        {
            popWindow();
        }
        searchButton.setDisable(false);
    }
    
    
    class StopAction implements EventHandler {

        @Override
        public void handle(Event t) {
            searchThread.setEnd(true);
        }
    
    }    

       
}
